﻿namespace Ex20
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite o seu nome: ");
            string nomeusu = Console.ReadLine() ?? "";

            Saudar(nomeusu);

        
        }
        static void Saudar(string nome)
        {
            
            Console.WriteLine($"\nOlá, {nome}!");
        }
    }
}
