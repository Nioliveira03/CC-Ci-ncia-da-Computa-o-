﻿namespace Ex8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("Digite um número inteiro: ");
            int num1 = int.Parse(Console.ReadLine());

            if (num1 > 0)
            {
                Console.WriteLine("Seu número " + num1 + " é positivo");
            }
            else if (num1 < 0)
            {
                Console.WriteLine("Seu número " + num1 + " é negativo");
            }
            else
            {
                Console.WriteLine("Zero");
            }

        }
    }
}
