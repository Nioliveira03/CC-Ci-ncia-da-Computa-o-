﻿namespace Ex25
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int saldo = 1000;
            int opcao;

            do
            {
                Console.WriteLine("\n--- CAIXA ELETRÔNICO ---");
                Console.WriteLine("1 - Consultar saldo");
                Console.WriteLine("2 - Depositar");
                Console.WriteLine("3 - Sacar");
                Console.WriteLine("0 - Sair");
                Console.Write("Escolha uma opção: ");

                opcao = int.Parse(Console.ReadLine() ?? "0");

                switch (opcao)
                {
                    case 1:
                        Console.WriteLine($"Saldo atual: R$ {saldo}");
                        break;

                    case 2:
                        Console.Write("Digite o valor do depósito: ");
                        int deposito = int.Parse(Console.ReadLine() ?? "0");

                        if (deposito > 0)
                        {
                            saldo += deposito;
                            Console.WriteLine($"Saldo atualizado: R$ {saldo}");
                        }
                        else
                        {
                            Console.WriteLine("Valor inválido.");
                        }

                        break;

                    case 3:
                        Console.Write("Digite o valor do saque: ");
                        int saque = int.Parse(Console.ReadLine() ?? "0");

                        if (saque > 0 && saque <= saldo)
                        {
                            saldo -= saque;
                            Console.WriteLine($"Saldo atualizado: R$ {saldo}");
                        }
                        else if (saque > saldo)
                        {
                            Console.WriteLine("Saldo insuficiente.");
                        }
                        else
                        {
                            Console.WriteLine("Valor inválido.");
                        }

                        break;

                    case 0:
                        Console.WriteLine("Saindo...");
                        break;

                    default:
                        Console.WriteLine("Opção inválida.");
                        break;
                }

            } while (opcao != 0);

        }
    }
}
