﻿namespace Ex29
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numero;

            do
            {
                Console.Write("Digite um número inteiro entre 1 e 10: ");
                numero = int.Parse(Console.ReadLine());

                if (numero < 1 || numero > 10)
                {
                    Console.WriteLine("Valor inválido! Digite um número entre 1 e 10.");
                }

            } while (numero < 1 || numero > 10);

            int fatorial = 1;

            for (int i = numero; i >= 1; i--)
            {
                fatorial *= i;
            }

            Console.WriteLine($"Fatorial de {numero}: {fatorial}");
        }
    }
}
