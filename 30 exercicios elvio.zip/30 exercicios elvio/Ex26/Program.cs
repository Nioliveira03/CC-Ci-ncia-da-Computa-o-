﻿namespace Ex26
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] notas = { 8, 6, 7, 4, 9, 5, 10, 3 };

            int aprovados = 0;
            int reprovados = 0;
            int soma = 0;

            foreach (int nota in notas)
            {
                soma += nota;

                if (nota >= 7)
                {
                    aprovados++;
                }
                else
                {
                    reprovados++;
                }
            }

            Console.WriteLine($"Quantidade de aprovados: {aprovados}");
            Console.WriteLine($"Quantidade de reprovados: {reprovados}");
            Console.WriteLine($"Soma total das notas: {soma}");
        }
    }
}
