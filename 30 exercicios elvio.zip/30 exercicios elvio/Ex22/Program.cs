﻿namespace Ex22
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite o primeiro número inteiro: ");
            int a = int.Parse(Console.ReadLine() ?? "0");

            Console.WriteLine("Digite o segundo número inteiro: ");
            int b = int.Parse(Console.ReadLine() ?? "0");

            if (a == b)
            {
                Console.WriteLine("Os números são iguais");

            }

            Console.WriteLine($"O número maior é = {MaiorDeDois(a, b)}");

        }



        static int MaiorDeDois(int a, int b)
            {   
                
                if (a > b)
                {
                    return a;
                }
               else
                {
                    return b;
                }
            }

    }
}
