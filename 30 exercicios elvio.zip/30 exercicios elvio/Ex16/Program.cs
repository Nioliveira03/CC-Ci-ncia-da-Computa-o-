﻿namespace Ex16
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int opcao = 0;
            Console.WriteLine("Digite um número para escolher um dia da semana:\n\n 1 = Domingo\n 2 = Segunda-feira\n 3 = Terça-feira\n 4 = Quarta-feira\n 5 = Quinta-feira\n 6 = Sextafeira\n 7 = Sábado\n");
              opcao = int.Parse(Console.ReadLine());

            switch (opcao)
            {
                case 1:
                    Console.WriteLine("Domingo");
                    break;

                case 2:
                    Console.WriteLine("Segunda-feira");
                    break;

                case 3:
                    Console.WriteLine("Terça-feira");
                    break;

                case 4:
                    Console.WriteLine("Quarta-feira");
                    break;

                case 5:
                    Console.WriteLine("Quinta-feira");
                    break;

                case 6:
                    Console.WriteLine("Sexta-feira");
                    break;

                case 7:
                    Console.WriteLine("Sábado");
                    break;

                default:
                    Console.WriteLine("Dia inválido!");
                    break;
            }
                
        
        
        
        
        
        
        
        
        
        
        
        
        
        }
    }
}
