﻿namespace Ex11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //exercicio 11 - Tabuada de um numero
            int resul = 0;
            Console.WriteLine("Digite um número");
            int num = int.Parse(Console.ReadLine());

            for (int i = 1; i <= 10; i++)
            {
                resul = num * i;
                Console.WriteLine(num +"X"+ i + "=" + resul);
            }

                
        }
    }
}
