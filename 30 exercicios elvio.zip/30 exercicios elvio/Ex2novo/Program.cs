﻿namespace Ex2novo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Exercicio 2 -  Quatro operações com dois números 
            Console.WriteLine("Digiteo primeiro número inteiro: ");
            int n1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite o segundo número inteiro: ");
            int n2 = int.Parse(Console.ReadLine());

            int soma = n1 + n2;
            int dif = n1 - n2;
            int prod = n1 * n2;
            int quot = n1 / n2;

            Console.WriteLine("Soma: " + soma + "| Subtração: " + dif + "| Multiplacação: " + prod + "| Divisão: " + quot);
        }
    }
}
