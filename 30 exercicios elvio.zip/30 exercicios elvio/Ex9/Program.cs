﻿namespace Ex9
{
    internal class Program
    {
        static void Main(string[] args)
        {
 
            Console.WriteLine("===== MENU ===== \n 1 - Cadastrar \n 2 - Consultar \n 3 - Editar \n 4 - Excluir \n 0 - Sair ");
            int opcao = int.Parse(Console.ReadLine()); 

            switch (opcao)
            {
                case 1:
                    Console.WriteLine("Você escolheu CADASTRAR");
                    break;

                case 2:
                    Console.WriteLine("Você escolheu CONSULTAR");
                    break;

                case 3:
                    Console.WriteLine("Você escolheu EDITAR");
                    break;

                case 4:
                    Console.WriteLine("Você escolheu EXCLUIR");
                    break;

                case 0:
                    Console.WriteLine("Saindo...");
                    break;

                default:
                    Console.WriteLine("Opção inválida!");
                    break;
            }

           


        }
    }
}
