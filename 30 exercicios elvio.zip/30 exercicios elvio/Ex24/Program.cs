﻿namespace Ex24
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numchute = 0, num = 37;
            int tentativas = 0;

            do
            {
                tentativas++;
                Console.WriteLine("Digite um número inteiro para descobrir qual o número inteiro secreto: ");
                numchute = int.Parse(Console.ReadLine());

                if (numchute == num)
                {
                    Console.WriteLine("Acertou!");
                }

                else if (numchute >= 36 && numchute <= 38)
                {
                    Console.WriteLine("Está BEM perto!");
                }

                else if (numchute >= 30 && numchute <= 35)
                {
                    Console.WriteLine("Está perto!");
                }


                else if (numchute > num)
                {
                    Console.WriteLine("O número secreto é menor");
                }

                else 
                {
                    Console.WriteLine("O número secreto é maior");
                }

            } while (numchute != num);

            Console.WriteLine($"Você acertou em {tentativas} tentativas!\");");
        }
    }
}
