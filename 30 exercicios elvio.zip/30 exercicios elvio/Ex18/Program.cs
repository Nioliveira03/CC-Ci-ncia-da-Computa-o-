﻿
namespace Ex18
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] nomes = { "Ana", "Bruno", "Carlos", "Diana", "Eduardo" };
             foreach (string nome in nomes)
            {

                Console.WriteLine($"Olá, {nome}!");
            }

        }
    }
}
