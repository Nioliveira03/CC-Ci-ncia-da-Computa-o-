﻿namespace PrimeiroConsole
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Exercicio 1 - Saudação personalizada 
            
            Console.WriteLine("Digite seu nome: ");
            string nome = Console.ReadLine();

            Console.WriteLine("Olá," + nome + " Bem - vindo(a) aos estudos de C#!");

        }
    }
}
