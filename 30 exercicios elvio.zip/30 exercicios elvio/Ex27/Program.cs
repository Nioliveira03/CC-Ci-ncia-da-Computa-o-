﻿using System;

class Program
{
    static void ExibirMenu()
    {
        Console.WriteLine("\n CENTRAL DE UTILIDADES NUMÉRICAS ");
        Console.WriteLine("1 - Verificar par/ímpar");
        Console.WriteLine("2 - Verificar positivo/negativo/zero");
        Console.WriteLine("3 - Mostrar tabuada");
        Console.WriteLine("0 - Sair");
        Console.Write("Escolha uma opção: ");
    }

    static void VerificarParImpar()
    {
        Console.Write("Digite um número: ");
        int numero = int.Parse(Console.ReadLine());

        if (numero % 2 == 0)
            Console.WriteLine("O número é par.");
        else
            Console.WriteLine("O número é ímpar.");
    }

    static void VerificarPositivoNegativoZero()
    {
        Console.Write("Digite um número: ");
        int numero = int.Parse(Console.ReadLine());

        if (numero > 0)
            Console.WriteLine("O número é positivo.");
        else if (numero < 0)
            Console.WriteLine("O número é negativo.");
        else
            Console.WriteLine("O número é zero.");
    }

    static void MostrarTabuada()
    {
        Console.Write("Digite um número: ");
        int numero = int.Parse(Console.ReadLine());

        Console.WriteLine($"\nTabuada do {numero}:");

        for (int i = 1; i <= 10; i++)
        {
            Console.WriteLine($"{numero} x {i} = {numero * i}");
        }
    }

    static void Main()
    {
        int opcao;

        do
        {
            ExibirMenu();
            opcao = int.Parse(Console.ReadLine());

            switch (opcao)
            {
                case 1:
                    VerificarParImpar();
                    break;

                case 2:
                    VerificarPositivoNegativoZero();
                    break;

                case 3:
                    MostrarTabuada();
                    break;

                case 0:
                    Console.WriteLine("Programa encerrado.");
                    break;

                default:
                    Console.WriteLine("Opção inválida");
                    break;
            }

        } while (opcao != 0);
    }
}
