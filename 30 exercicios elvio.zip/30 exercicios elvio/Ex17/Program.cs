﻿namespace Ex17
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num = 0, resto =0, i =0, contador = 0;
            Console.WriteLine("Digite um número inteiro positivo: ");
            num = int.Parse(Console.ReadLine());


            Console.WriteLine("Pares: ");

          for (i = 1; i < num; i++)
            {
                resto = (i % 2);

                if (resto == 0)
                {
                    Console.WriteLine( i + " " );
                    contador++;
                }

            }

            Console.WriteLine($"\nQuantidade: {contador} ");

        }
    }
}
