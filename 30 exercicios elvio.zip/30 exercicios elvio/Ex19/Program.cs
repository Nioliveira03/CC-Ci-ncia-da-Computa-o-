﻿namespace Ex19
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] valores = { 10, 5, 8, 12, 3, 7 };
            int soma = 0;

            foreach (int valor in valores)
            {
                soma = soma + valor;
                
            }
            Console.WriteLine($"Valor total: {soma}");
        }
    }
}
