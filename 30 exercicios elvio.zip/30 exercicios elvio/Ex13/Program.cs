﻿namespace Ex13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num;

            do
            {

                Console.WriteLine("Digite um número inteiro positivo: ");
                num = int.Parse(Console.ReadLine());


                if (num <= 0)
                {
                    Console.WriteLine("Número Inválido! Tente novamente");
                }

            } while (num <= 0);

            Console.WriteLine("Número Válido! ");


        }  
    }
}
