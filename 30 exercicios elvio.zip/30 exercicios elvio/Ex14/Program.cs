﻿using System.Runtime.Intrinsics.X86;

namespace Ex14
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int nota = 0;

                Console.WriteLine("\nDigite a nota inteira de 0 a 10: ");
                nota = int.Parse(Console.ReadLine());

                if (nota < 0 || nota > 10)
                {
                    Console.WriteLine("Nota invalida!");
                }

                else if (nota <= 4)
                {
                    Console.WriteLine("Insuficiente!");
                }
                else if ( nota <= 6)
                {
                    Console.WriteLine("Regular!");
                }
                else if (nota <= 8)
                {
                    Console.WriteLine("Bom!");
                }
                else 
                {
                    Console.WriteLine("Exelente!");
                }

        }
    }
}
