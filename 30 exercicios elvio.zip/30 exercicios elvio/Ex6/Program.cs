﻿namespace Ex6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            float resto;
            Console.WriteLine("Digite um número inteiro: ");
            int num = int.Parse(Console.ReadLine());

             resto = num % 2;


            if (resto == 0)
            {
                Console.WriteLine("Seu número" + num +  "é par ");
            }
            else
            {
                Console.WriteLine("Seu número" + num + "é impar ");
            }


        }
    }
}
