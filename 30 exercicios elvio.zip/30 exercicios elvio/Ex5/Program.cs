﻿namespace Ex5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Exercicio 5 - Maior ou menor de idade
            Console.WriteLine("Digite sua idade:");
            int idade = int.Parse(Console.ReadLine());

            if (idade >= 18)
            {
                Console.WriteLine("Maior de idade");
            }
            else
            {
                Console.WriteLine("Menor de idade");
            }
        }
    }
}