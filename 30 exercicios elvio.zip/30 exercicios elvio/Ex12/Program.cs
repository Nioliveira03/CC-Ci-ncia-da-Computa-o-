﻿namespace Ex12
{
    internal class Program
    {
        static void Main(string[] args)
        {
                int resul = 0;
                Console.WriteLine("Digite um número inteiro: ");
                int num = int.Parse(Console.ReadLine());

            int i = 1, soma = 0;

                if (num > 0)
                {
                    while (i <= num)
                    {
                        soma += i;
                        i++;
                    }
                }
            Console.WriteLine("Soma: " + soma);
        }
    }
}

    

