﻿namespace Ex30
{
    internal class Program
    {
            static void ExibirMenu()
            {
                Console.WriteLine("\n=== MENU DE PEDIDOS ===");
                Console.WriteLine("1 - Sanduíche - R$ 20");
                Console.WriteLine("2 - Suco - R$ 8");
                Console.WriteLine("3 - Sobremesa - R$ 12");
                Console.WriteLine("0 - Finalizar pedido");
                Console.Write("Escolha uma opção: ");
            }

            static void MostrarTotal(int total)
            {
                Console.WriteLine($"\nTotal final do pedido: R$ {total}");
            }

            static void Main()
            {
                int opcao;
                int totalPedido = 0;

                do
                {
                    ExibirMenu();
                    opcao = int.Parse(Console.ReadLine());

                    switch (opcao)
                    {
                        case 1:
                            totalPedido += 20;
                            Console.WriteLine("Sanduíche adicionado!");
                            Console.WriteLine($"Total parcial: R$ {totalPedido}");
                            break;

                        case 2:
                            totalPedido += 8;
                            Console.WriteLine("Suco adicionado!");
                            Console.WriteLine($"Total parcial: R$ {totalPedido}");
                            break;

                        case 3:
                            totalPedido += 12;
                            Console.WriteLine("Sobremesa adicionada!");
                            Console.WriteLine($"Total parcial: R$ {totalPedido}");
                            break;

                        case 0:
                            Console.WriteLine("Pedido finalizado.");
                            break;

                        default:
                            Console.WriteLine("Opção inválida!");
                            break;
                    }

                } while (opcao != 0);

                MostrarTotal(totalPedido);
            }
        }

    }


