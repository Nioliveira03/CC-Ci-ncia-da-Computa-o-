﻿namespace Ex15
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int senha = 1234, senhausu = 0, i = 0;

            for (i = 1; i < 4; i++)
            {
                Console.WriteLine("\nDigite a senha: ");
                senhausu = int.Parse(Console.ReadLine());

                if (senha != senhausu)
                {
                    Console.WriteLine("Senha Inválida!");
                }
                else if (senha == senhausu)
                {
                    Console.WriteLine("\nAcesso permitido! ");
                    break;
                }

            }

            if (i > 3)
            {
                Console.WriteLine("\nAcesso negado! Houve mais de 3 tentativas!! ");
            }



        }
    }
}
