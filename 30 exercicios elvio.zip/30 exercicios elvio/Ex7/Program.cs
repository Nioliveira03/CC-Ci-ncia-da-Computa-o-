﻿namespace Ex7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite um número inteiro: ");
            int num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite outro número inteiro: ");
            int num2 = int.Parse(Console.ReadLine());

        if (num1 > num2)
            {
                Console.WriteLine("Seu número "+num1+ " é maior");
            }
        else if (num2 > num1)
            {
                Console.WriteLine("Seu número " + num2 + " é maior");
            }
        else
            {
                Console.WriteLine("Os numeros são iguais");
            }



        }
    }
}
