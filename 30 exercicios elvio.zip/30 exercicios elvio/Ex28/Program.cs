﻿namespace Ex28
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Digite um número inteiro positivo : ");
            int num = int.Parse(Console.ReadLine());

            int soma = 0;

            Console.WriteLine("Números considerados:");

            for (int i = 1; i <= num; i++)
            {
                if (i % 3 == 0 || i % 5 == 0)
                {
                    Console.WriteLine(i);
                    soma += i;
                }
            }

            Console.WriteLine($"Soma total: {soma}");
        }
    }
}
