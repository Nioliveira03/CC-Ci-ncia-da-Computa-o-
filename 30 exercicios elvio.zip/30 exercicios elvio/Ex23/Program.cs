﻿namespace Ex23
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            
            for (int i=1; i<51;i++)
            {
                int mul3 = 3;
                int mul5 = 5;
               

                if (i % mul3 == 0 && i % mul5 == 0)
                {
                    Console.WriteLine($"{i} é múltiplo de {mul3} e {mul5}");
                }
                else if (i % mul3 == 0)
                {
                    Console.WriteLine($"{i} é múltiplo só de {mul3}");
                } 
                else if (i % mul5 == 0)
                {
                    Console.WriteLine($"{i} é múltiplo só de {mul5}");
                }
                else
                {
                    Console.WriteLine($"{i}");
                }
            }



        }
    }
}
