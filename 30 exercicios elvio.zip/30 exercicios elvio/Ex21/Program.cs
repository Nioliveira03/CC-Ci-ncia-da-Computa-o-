﻿namespace Ex21
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite o primeiro número inteiro: ");
            int n1 = int.Parse(Console.ReadLine() ?? "0");

            Console.WriteLine("Digite o segundo número inteiro: ");
            int n2 = int.Parse(Console.ReadLine() ?? "0");

            Console.WriteLine("\nEscolha uma operação:\n1 - Somar\n2 - Subtrair\n3 - Multiplicar\n4 - Dividir");
            int opcao = int.Parse(Console.ReadLine() ?? "0");

            switch (opcao)
            {
                case 1:
                    Console.WriteLine($"Resultado = {Somar(n1, n2)}");
                    break;

                case 2:
                    Console.WriteLine($"Resultado = {Subtrair(n1, n2)}");
                    break;

                case 3:
                    Console.WriteLine($"Resultado = {Multiplicar(n1, n2)}");
                    break;

                case 4:
                   
                    if (n2 != 0)
                    {
                        Console.WriteLine($"Resultado = {Dividir(n1, n2)}");
                    }
                    else
                    {
                        Console.WriteLine("A divisão não pode ser realizada.");
                    }
                    break;

                default:
                    Console.WriteLine("Opção inválida");
                    break;
            }
        }

        static int Somar(int a, int b)
        {
            return a + b;
        }

        static int Subtrair(int a, int b)
        {
            return a - b;
        }

        static int Multiplicar(int a, int b)
        {
            return a * b;
        }

        static int Dividir(int a, int b)
        {
            return a / b;
        }
    }

}

